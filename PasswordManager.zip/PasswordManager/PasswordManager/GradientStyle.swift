//
//  GradientButtonStyle.swift
//  PasswordManager
//
//  Created by 2169955 on 27/07/24.
//

import Foundation
import SwiftUI

struct GradientButton: ButtonStyle{
    func makeBody(configuration: Configuration) -> some View {
        configuration
            .label
            .padding(.horizontal, 30)
            .padding(.vertical)
            .frame(width: 350)
            .cornerRadius(40)
            .background(.black)
            .cornerRadius(50)
    }
}



