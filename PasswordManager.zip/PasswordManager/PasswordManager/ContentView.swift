//
//  ContentView.swift
//  PasswordManager
//
//  Created by 2169955 on 26/07/24.
//

import SwiftUI
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext

    @FetchRequest(entity: Item.entity(), sortDescriptors: [NSSortDescriptor(keyPath: \Item.accountName, ascending: false)])
    var items:FetchedResults<Item>
    
    
    
    @State private var isShowingSheet:Bool = false

    var body: some View {
        ZStack{
            
            Color.gray.opacity(0.3).ignoresSafeArea()
            VStack{
              //  Color.red
                Text("Password Manager")
                    .font(.title)
                    .padding(.top, 20)
                    .multilineTextAlignment(.leading)
                ForEach(items) { item in
                    CustomButtonView(accType: item.accountName!, username: item.userName!, password: item.passWord!)
                }
            }.offset(y:-270)
            
            Button{
                print("Add Button Pressed")
                isShowingSheet.toggle()
            }label:{
                Image("AddButton")
            }.sheet(isPresented: $isShowingSheet, content: {
                CustomAddDetailView(accountName: "", userName: "", password: "", encryptedPassword: "")
                    .presentationDragIndicator(.visible)
                    .presentationDetents([.medium,.large])
            })
                .frame(width: 60,height: 60)
                .offset(x:140,y:320)
        }//:ZSTACK
       
        
       
    }

    private func addItem() {
        withAnimation {
            //let newItem = Item(context: viewContext)
           // newItem.timestamp = Date()

            do {
                //try viewContext.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }

    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            //offsets.map { items[$0] }.forEach(viewContext.delete)

            do {
               // try viewContext.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
}

private let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .medium
    return formatter
}()

#Preview {
    ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
}
