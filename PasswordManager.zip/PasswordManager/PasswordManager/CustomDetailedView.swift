//
//  CustomDetailedView.swift
//  PasswordManager
//
//  Created by 2169955 on 28/07/24.
//

import SwiftUI

struct CustomDetailedView: View {
    @Environment(\.managedObjectContext) private var viewContext

    @FetchRequest(entity: Item.entity(), sortDescriptors: [NSSortDescriptor(keyPath: \Item.accountName, ascending: false)])
    var items:FetchedResults<Item>
    @State private var isSecured: Bool = true
    var accountType:String
    var userName:String
    var password:String
    
    
    var body: some View {
        VStack{
            Text("Account Details")
                .font(.system(size: 30))
                .fontWeight(.medium)
                .foregroundColor(.blue)
                .padding(.trailing, 120)
                .padding(.bottom, 30)
            
            Text("Account Type")
                .font(.system(size: 10))
                .foregroundStyle(.gray)
                .padding(.trailing, 262)
            //ForEach(items) { item in
                 Text(accountType)
                .multilineTextAlignment(.trailing)
                .font(.system(size: 18))
                .fontWeight(.heavy)
                .frame(maxWidth: .infinity)
                .frame(height: 50)
//                .font(.system(size: 18))
//                .fontWeight(.heavy)
//                .padding(.trailing, 282)
//                .padding(.bottom, 30)
          //  }
            Text("Username/ Email")
                .font(.system(size: 10))
                .foregroundStyle(.gray)
                .padding(.trailing, 249)
          //  ForEach(items) { item in
                Text(userName)
                .multilineTextAlignment(.trailing)
                .font(.system(size: 18))
                .fontWeight(.heavy)
                .frame(maxWidth: .infinity)
                .frame(height: 50)
//                .font(.system(size: 18))
//                .fontWeight(.heavy)
//                .frame(maxWidth: .infinity)
//                .padding(.trailing, 282)
//                .padding(.bottom, 30)
           // }
            
            Text("Password")
                .font(.system(size: 10))
                .foregroundStyle(.gray)
                .padding(.trailing, 280)
            
            HStack{
                
                //ForEach(items){ item in
                    if isSecured{
                        Text("*********")
                            .multilineTextAlignment(.trailing)
                            .font(.system(size: 18))
                            .fontWeight(.heavy)
                            .frame(maxWidth: .infinity)
                            .frame(height: 50)
                    }else{
                        Text(password)
                            .multilineTextAlignment(.trailing)
                            .font(.system(size: 18))
                            .fontWeight(.heavy)
                            .frame(maxWidth: .infinity)
                            .frame(height: 50)
                    }
             //   }
                
                Button{
                    print("Eye Button Pressed")
                    isSecured.toggle()
                }label: {
                    Image(systemName: "eye.slash")
                }
            }.padding()
                .frame(width: 350,height: 50)
            
            HStack{
                Button{
                    print("Edit Button Pressed")
                }label: {
                    ZStack{
                        RoundedRectangle(cornerRadius: 40)
                            .frame(width: 160,height: 40)
                            .foregroundColor(.black)
                        Text("Edit")
                            .foregroundColor(.white)
                            .fontWeight(.heavy)
                    }
                    
                }.padding()
                
                Button{
                    print("Delete Button Pressed")
                    
                }label: {
                    ZStack{
                        RoundedRectangle(cornerRadius: 40)
                            .frame(width: 160,height: 40)
                            .foregroundColor(.red)
                        Text("Delete")
                            .foregroundColor(.white)
                            .fontWeight(.heavy)
                    }
                    
                }
            }
        }
    }
}

#Preview {
    CustomDetailedView(accountType: "", userName: "", password: "")
}
