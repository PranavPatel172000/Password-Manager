//
//  CustomButtonView.swift
//  PasswordManager
//
//  Created by 2169955 on 27/07/24.
//

import SwiftUI
import CryptoKit


struct CustomButtonView: View {
    
    @State var accType:String
    @State var username:String
    @State var password:String
    @State var isShowingDetailView:Bool = false
    
    
    var body: some View {
        Button{
            print("The Custom Button was Pressed.")
            isShowingDetailView.toggle()
        }label: {
            CustomButtonViewStyle(accType: accType)
        }.sheet(isPresented: $isShowingDetailView, content: {
            CustomDetailedView(accountType: accType, userName: username, password: PasswordSingleton.shared.accPassword)
            .presentationDragIndicator(.visible)
                .presentationDetents([.medium,.large])
        })
    }
}

#Preview {
    CustomButtonView(accType: "", username: "", password: "", isShowingDetailView: false)
}
