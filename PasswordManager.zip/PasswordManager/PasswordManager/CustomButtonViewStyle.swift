//
//  CustomButtonViewStyle.swift
//  PasswordManager
//
//  Created by 2169955 on 27/07/24.
//

import SwiftUI

struct CustomButtonViewStyle: View {
    
    @State var accType:String
    
    var body: some View {
        ZStack{
            Rectangle()
                .cornerRadius(60)
                .frame(width: 360, height: 90)
                .foregroundColor(.white)
            HStack(spacing:170){
                HStack(){
                    Text(accType)
                        .font(.title)
                        .fontWeight(.medium)
                        .foregroundColor(.black)
                    Text("******")
                        .font(.system(size: 30))
                        .fontWeight(.regular)
                        .foregroundColor(.black)
                        .offset(y:8)
                }.offset(x:20)
                Image(systemName: "chevron.right")
                    .offset(x:-20)
                    .frame(width: 20, height: 30)
                    .foregroundColor(.black)
            }//:HSTACK
        }//: ZSTACK
    }
}

#Preview {
    CustomButtonViewStyle(accType: "")
}
