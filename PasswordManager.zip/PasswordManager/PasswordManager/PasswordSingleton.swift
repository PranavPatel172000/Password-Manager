//
//  PasswordSingleton.swift
//  PasswordManager
//
//  Created by 2169955 on 29/07/24.
//

import Foundation

class PasswordSingleton{
    static let shared  = PasswordSingleton()
    
    var accPassword:String = ""
}
