//
//  CustomAddDetailView.swift
//  PasswordManager
//
//  Created by 2169955 on 27/07/24.
//

import SwiftUI
import CryptoKit

struct CustomAddDetailView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) var dismiss
    @State var accountName:String
    @State var userName:String
    @State var password:String
    @State var encryptedPassword:String
    
    var body: some View {
        Section{
            VStack(spacing:30){
                TextField("  Account Name", text: $accountName)
                    .frame(width: 350, height: 50)
                    .textFieldStyle(PlainTextFieldStyle())
                    .padding([.horizontal], 4)
                    .cornerRadius(16)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray))
                    .padding([.horizontal], 24)
                TextField("  Username/Email", text: $userName)
                    .frame(width: 350, height: 50)
                    .textFieldStyle(PlainTextFieldStyle())
                    .padding([.horizontal], 4)
                    .cornerRadius(16)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray))
                    .padding([.horizontal], 24)
                SecureField("  Password", text: $password)
                    .frame(width: 350, height: 50)
                    .textFieldStyle(PlainTextFieldStyle())
                    .padding([.horizontal], 4)
                    .cornerRadius(16)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray))
                    .padding([.horizontal], 24)
                Button{
                    print("Add Account Button Pressed")
                    addItem()
                    dismiss()
                }label:{
                    Text("Add New Account")
                        .font(.title3)
                        .fontWeight(.heavy)
                        .foregroundStyle(.white)
                }.buttonStyle(GradientButton())
            }//: VSTACK
        }//: SECTION
    }
    
    func encryptAES(plainText: String, key: SymmetricKey)throws -> Data{
        let data = Data(plainText.utf8)
        let sealedBox = try AES.GCM.seal(data, using: key)
        return sealedBox.combined!
        }
    
    private func addItem() {
        withAnimation {
            let newItem = Item(context: viewContext)
            newItem.accountName = accountName
            newItem.userName = userName
            PasswordSingleton.shared.accPassword = password
            accountName = ""
            userName = ""
            
            let key = SymmetricKey(size: .bits256)
            do {
                  // Encrypt Password
                  let encryptedData = try encryptAES(plainText: password, key: key)
                  print("Encrypted Data: \(encryptedData.base64EncodedString())")
                  encryptedPassword = encryptedData.base64EncodedString()
                  newItem.passWord = encryptedPassword
                  
                
              } catch {
                  print("Error: \(error)")
              }
            
        }
    }
    
    private func saveItems(){
        do {
            try viewContext.save()
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
}

#Preview {
    CustomAddDetailView(accountName: "", userName: "", password: "", encryptedPassword: "")
}
